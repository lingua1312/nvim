---@type ChadrcConfig
local M = {}

M.ui = {
  theme = "doom",
  nvdash = {
    load_on_startup = true, -- important to actually load Alpha
  },
}

return M

